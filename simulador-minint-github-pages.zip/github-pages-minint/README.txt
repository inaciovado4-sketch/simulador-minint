SIMULADOR MININT ANGOLA - PUBLICACAO NO GITHUB PAGES

1. Extraia este ZIP.
2. Entre em https://github.com e crie um repositório público chamado simulador-minint.
3. Escolha Add file > Upload files.
4. Envie o ficheiro index.html (e este README, se desejar).
5. Clique em Commit changes.
6. Abra Settings > Pages.
7. Em Build and deployment, escolha Deploy from a branch.
8. Selecione Branch: main e Folder: / (root). Clique Save.
9. Aguarde a publicação. O endereço será semelhante a:
   https://SEU-UTILIZADOR.github.io/simulador-minint/
10. Copie esse endereço e partilhe com os candidatos.

IMPORTANTE:
Esta publicação disponibiliza a versão estática. O ficheiro usa localStorage e não tem integração com uma base de dados/servidor. Assim, os dados de cada navegador não são partilhados com o administrador nem entre candidatos. Não utilize os códigos/pagamentos como sistema seguro até integrar backend, autenticação e base de dados.
